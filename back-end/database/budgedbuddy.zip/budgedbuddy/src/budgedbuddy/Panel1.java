package budgedbuddy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Panel1 extends JFrame{

	private JPanel panel = new JPanel();
	private JButton CreateUser = new JButton("Create a new Account");
	private JButton Login = new JButton("Login");
	
	public Panel1() {
		
		panel.add(CreateUser);
		panel.add(Login);
		this.setContentPane(panel);
		
		CreateUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Panel2NewUser();
			}
			
		});
		
		Login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new LoginPanel();
			}
			
		});
		
		this.setVisible(true);
		this.setSize(200,200);
		this.setTitle("Budget Buddy");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
