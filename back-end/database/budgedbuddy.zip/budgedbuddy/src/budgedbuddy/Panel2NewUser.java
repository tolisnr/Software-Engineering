package budgedbuddy;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Panel2NewUser extends JFrame{
	

	private JPanel panel = new JPanel();
	private JLabel text1 = new JLabel("Δώσε όνομα χρήστη:");
	private JTextField username = new JTextField();
	private JLabel text2 = new JLabel("Δημιούργησε ένα κωδικό:");
	private JTextField password = new JTextField();
	private JButton save = new JButton("Save");
	
	public Panel2NewUser() {
		
		panel.add(text1);
		username.setPreferredSize(new Dimension(200, 30));
		panel.add(username);
		panel.add(text2);
		password.setPreferredSize(new Dimension(200, 30));
		panel.add(password);
		panel.add(save);
		this.setContentPane(panel);
		
		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				User user = new User(username.getText(), password.getText());
				user.InsertUserinDataBase(user);
			}
			
		});
		
		this.setVisible(true);
		this.setSize(300,300);
		this.setTitle("Create Profil");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
