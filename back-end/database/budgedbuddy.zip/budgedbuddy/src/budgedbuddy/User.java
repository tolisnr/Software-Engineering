package budgedbuddy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class User {

	public String userID;
	public static String username;
	public static String password;
	public ArrayList<Team> Groups = new ArrayList<Team>();
	
	
	public User(String name, String  password) {
		this.username = name;
		this.password = password;
	}
	
	public void JoinGroup() {
		Scanner keyboard = new Scanner(System.in);
		String code = keyboard.next();
		for (Team group : Groups) {
			if(code == group.getTeamID()) {
				group.addUser(this);
			}
		}
	}
	
	public void CreateGroup() {
		Scanner keyboard = new Scanner(System.in);
		
		String title = keyboard.next();
		String password = keyboard.next();
		String category = keyboard.next();
		String description = keyboard.next();
		int maxMembers = keyboard.nextInt();
		
		Team group = new Team(password, title, category, description, this, maxMembers);
	
	}
	
	public void InsertUserinDataBase(User user) {
		
		 	String url = "jdbc:mysql://localhost:3306/budgedbuddies"; // Το URL της βάσης δεδομένων σας
	        String username = "root"; // Το όνομα χρήστη της βάσης δεδομένων
	        String password = ""; // Ο κωδικός πρόσβασης στη βάση δεδομένων

	        // Προσθήκη νέου χρήστη στη βάση δεδομένων
	        try (Connection connection = DriverManager.getConnection(url, username, password)) {
	            String insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
	            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery, PreparedStatement.RETURN_GENERATED_KEYS);
	            preparedStatement.setString(1, user.getName());
	            preparedStatement.setString(2, user.getPassword());

	            int rowsInserted = preparedStatement.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Ο νέος χρήστης προστέθηκε με επιτυχία!");

	                // Λήψη του αυξανόμενου userID
	                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
	                    if (generatedKeys.next()) {
	                        int userID = generatedKeys.getInt(1);
	                        System.out.println("Το αυξανόμενο userID είναι: " + userID);
	                    } else {
	                        System.out.println("Αποτυχία λήψης του αυξανόμενου userID.");
	                    }
	                }
	            }
	        } catch (SQLException e) {
	            System.out.println("Προέκυψε σφάλμα κατά την προσθήκη νέου χρήστη: " + e.getMessage());
	        }
	    }

	
	
	public static String getName() {
		return username;
	}

	public static String getPassword() {
		return password;
	}
	
	
}
