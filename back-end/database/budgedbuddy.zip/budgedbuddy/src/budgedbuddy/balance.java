package budgedbuddy;

import java.util.Map;

public class balance {

	private String balanceID;
	private Team team;
	private Map amountOwed;
	
}
