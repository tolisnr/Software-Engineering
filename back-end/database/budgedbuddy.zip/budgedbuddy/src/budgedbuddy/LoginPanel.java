package budgedbuddy;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginPanel extends JFrame {

    private JPanel panel = new JPanel();
    private JLabel text1 = new JLabel("Username:");
    private JTextField username = new JTextField();
    private JLabel text2 = new JLabel("Password");
    private JTextField password = new JTextField();
    private JButton login = new JButton("Login");

    public LoginPanel() {

        panel.add(text1);
        username.setPreferredSize(new Dimension(200, 30));
        panel.add(username);
        panel.add(text2);
        password.setPreferredSize(new Dimension(200, 30));
        panel.add(password);
        panel.add(login);
        this.setContentPane(panel);

        login.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // Καλέστε την μέθοδο authenticateUser για να ελέγξετε τα στοιχεία σύνδεσης
                String name = username.getText();
                String pass = password.getText();

                if (authenticateUser(name, pass)) {
                    System.out.println("User authenticated successfully.");
                } else {
                    System.out.println("Authentication failed.");
                }
            }

        });

        this.setVisible(true);
        this.setSize(300, 300);
        this.setTitle("Login");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // Μέθοδος για επαλήθευση των στοιχείων σύνδεσης στη βάση δεδομένων
    public static boolean authenticateUser(String username, String password) {
        // Καλείτε την μέθοδο getConnection() για τη σύνδεση στη βάση δεδομένων
        try (Connection conn = XAMPPConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            // Εάν βρέθηκε μια εγγραφή με τα συγκεκριμένα στοιχεία σύνδεσης, η σύνδεση είναι επιτυχής
            if (resultSet.next()) {
                System.out.println("Login successful!");
                return true;
            } else {
                System.out.println("Login failed. Incorrect username or password.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error during login: " + e.getMessage());
            return false;
        }
    }
}
