package budgedbuddy;

import java.util.ArrayList;

public class Team {

	public String teamID;
	public ArrayList<User> Users = new ArrayList<>();
	public String title, category;
	public User admin;
	
	
	public Team(String code, String title, String category, User admin) {
		super();
		this.teamID = code;
		this.title = title;
		this.category = category;
		this.admin = admin;
	}

	public String getTeamID() {
		return teamID;
	}
	
	public void addUser(User user) {
		
		Users.add(user);
	}

	
}
