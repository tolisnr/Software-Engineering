
import java.util.Date;

public class expense {

	private String expanseID;
	private String tittle;
	private double amount;
	private Date date;
	private User payer;
	
	
}
