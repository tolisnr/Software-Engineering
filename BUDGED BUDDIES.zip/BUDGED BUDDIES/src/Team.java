
import java.util.ArrayList;

public class Team {

	public String teamID;
	public ArrayList<User> Users = new ArrayList<>();
	public String title, category;
	public int userIdAdmin;
	
	
	public Team(String code, String title, String category, int userIdAdmin) {
		super();
		this.teamID = code;
		this.title = title;
		this.category = category;
		this.userIdAdmin = userIdAdmin;
	}

	public String getTeamID() {
		return teamID;
	}
	
	public void addUser(User user) {
		
		Users.add(user);
	}

	public String getTitle() {
		return title;
	}

	public String getCategory() {
		return category;
	}

	public int getUserIdAdmin() {
		return userIdAdmin;
	}

	
}
