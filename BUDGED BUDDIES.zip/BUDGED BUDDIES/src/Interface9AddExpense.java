
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Interface9AddExpense extends JFrame{

	private JPanel panel = new JPanel();
	private JButton BACK = new JButton("BACK");
	
	public Interface9AddExpense(Team team, User user) {
		
		panel.add(BACK);
        this.setContentPane(panel);
        
        
        BACK.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface8Expenses(team, user);
				dispose();
			}
			
		});
        
        this.setVisible(true);
        this.setSize(300, 300);
        this.setTitle("Add Expense");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
