
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Interface4 extends JFrame{

	private JPanel panel = new JPanel();
	private JButton JoinTeam = new JButton("JOIN TEAM");
	private JButton CreateTeam = new JButton("CREATE TEAM");
	private JButton BACK = new JButton("BACK");
	
	public Interface4(User user) {

		panel.add(CreateTeam);
		panel.add(JoinTeam);
		panel.add(BACK);
		this.setContentPane(panel);
		
		CreateTeam.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new Interface6CreateTeam(user);
				dispose();
			}
			
		});
		
		JoinTeam.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface5JoinTeam(user);
				dispose();
			}
			
		});
		
		BACK.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface1();
				dispose();
			}
			
		});
		
		this.setVisible(true);
		this.setSize(300,300);
		this.setTitle("Budget Buddies");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
