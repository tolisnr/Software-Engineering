package budgedbuddy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Interface8Expenses extends JFrame{

	private JPanel panel = new JPanel();
	private JButton BACK = new JButton("BACK");
	
	public Interface8Expenses(Team team, User user) {
		
		panel.add(BACK);
        this.setContentPane(panel);
        
        
        BACK.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface7(team, user);
				dispose();
			}
			
		});
        
        this.setVisible(true);
        this.setSize(300, 300);
        this.setTitle("Expenses");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
