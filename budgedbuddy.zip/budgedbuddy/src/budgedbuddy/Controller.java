package budgedbuddy;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class Controller {

    @FXML
    private TextField namefield;

    @FXML
    private PasswordField passwordfield;

    @FXML
    public void create_user_action() {
        String username = namefield.getText();
        String password = passwordfield.getText();
        int id = 0;

        User user = new User(username, password, id);
        if (!user.doesUserExist(user.getUsername())) {
            user.InsertUserinDataBase(user);
            JOptionPane.showMessageDialog(null, "User created successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "User already exists!");
        }
    }

    @FXML
    public void back_action() {
        Stage stage = (Stage) namefield.getScene().getWindow();
        stage.close();
        new Interface1();  // Ανοίγει την αρχική διεπαφή
    }
}
