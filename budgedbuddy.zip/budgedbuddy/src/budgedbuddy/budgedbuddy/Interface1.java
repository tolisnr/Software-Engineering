package budgedbuddy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Interface1 extends JFrame{

	private JPanel panel = new JPanel();
	private JButton CreateUser = new JButton("Create a new Account");
	private JButton Login = new JButton("Login");
	
	public Interface1() {
		
		panel.add(CreateUser);
		panel.add(Login);
		this.setContentPane(panel);
		
		CreateUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface3NewUser();
				dispose();
			}
			
		});
		
		Login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Interface2Login();
				dispose();
			}
			
		});
		
		this.setVisible(true);
		this.setSize(300,300);
		this.setTitle("Budget Buddy");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
